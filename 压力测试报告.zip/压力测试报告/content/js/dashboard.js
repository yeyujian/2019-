/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 95.25550345704522, "KoPercent": 4.7444965429547805};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9516013669236271, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9991596638655462, 500, 1500, "/customer/delete_gateway"], "isController": false}, {"data": [1.0, 500, 1500, "/root/query_user_list"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/add_project_params"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/query_gateway"], "isController": false}, {"data": [0.0, 500, 1500, " /customer/query_last_data"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/delete_project_params"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/query_project_params"], "isController": false}, {"data": [1.0, 500, 1500, "login"], "isController": false}, {"data": [0.9991680532445923, 500, 1500, "/root/enable_user"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/modify_projectv"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/add_gateway"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/delete_project"], "isController": false}, {"data": [0.9991596638655462, 500, 1500, "/customer/query_history_data"], "isController": false}, {"data": [0.9995854063018242, 500, 1500, "/root/add_user"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/modify_gateway"], "isController": false}, {"data": [1.0, 500, 1500, "/root/disable_user"], "isController": false}, {"data": [1.0, 500, 1500, "/customer/register_project"], "isController": false}, {"data": [0.9833055091819699, 500, 1500, "/customer/query_project"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 12583, 597, 4.7444965429547805, 80.96137646030361, 8, 595, 155.0, 216.0, 371.47999999999956, 243.89912969316356, 1900.9091262889845, 83.61119111739451], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["/customer/delete_gateway", 595, 0, 0.0, 76.93445378151257, 22, 555, 130.0, 172.5999999999998, 247.3199999999997, 11.670327946022281, 47.45489623582888, 3.122724469931743], "isController": false}, {"data": ["/root/query_user_list", 602, 0, 0.0, 67.6046511627907, 16, 465, 106.0, 142.85000000000002, 243.77000000000112, 11.711834400108946, 6.862402968813836, 3.133830689091652], "isController": false}, {"data": ["/customer/add_project_params", 599, 0, 0.0, 74.08347245409018, 17, 471, 141.0, 180.0, 246.0, 11.733594515181194, 6.840777271057787, 8.135597759549462], "isController": false}, {"data": ["/customer/query_gateway", 597, 0, 0.0, 77.79564489112231, 25, 487, 137.0, 174.20000000000005, 246.5399999999995, 11.713002020836194, 6.943156471335517, 3.05407376910475], "isController": false}, {"data": [" /customer/query_last_data", 597, 597, 100.0, 57.57453936348409, 11, 385, 91.0, 128.20000000000005, 213.25999999999976, 11.696937635925469, 4.432042776112384, 3.118421850202786], "isController": false}, {"data": ["/customer/delete_project_params", 595, 0, 0.0, 69.36638655462177, 25, 288, 114.79999999999995, 160.79999999999973, 254.35999999999967, 11.695101816180516, 6.818335726816181, 3.380615368739681], "isController": false}, {"data": ["/customer/query_project_params", 599, 0, 0.0, 75.46911519198667, 24, 438, 145.0, 174.0, 259.0, 11.723031157037733, 6.834618750733913, 7.910756376477611], "isController": false}, {"data": ["login", 1819, 0, 0.0, 67.01759208356239, 8, 380, 108.0, 140.0, 206.79999999999973, 35.25808765094688, 62.67098503736116, 9.181534963704909], "isController": false}, {"data": ["/root/enable_user", 601, 0, 0.0, 67.79201331114805, 16, 515, 102.0, 147.89999999999998, 222.92000000000007, 11.706043902534036, 6.859010099141037, 2.949374342630646], "isController": false}, {"data": ["/customer/modify_projectv", 588, 0, 0.0, 76.19727891156461, 29, 406, 123.10000000000002, 173.0, 263.33000000000004, 11.575714623198678, 7.042646689699977, 3.945238675289393], "isController": false}, {"data": ["/customer/add_gateway", 599, 0, 0.0, 74.30717863105173, 20, 403, 145.0, 183.0, 261.0, 11.707679377675273, 6.825668543429823, 9.112324671882025], "isController": false}, {"data": ["/customer/delete_project", 593, 0, 0.0, 78.40303541315343, 26, 486, 137.60000000000002, 185.19999999999982, 253.39999999999782, 11.638404773119799, 47.79053692691161, 3.034623119553698], "isController": false}, {"data": ["/customer/query_history_data", 595, 0, 0.0, 69.39495798319325, 17, 526, 109.0, 157.39999999999986, 231.19999999999982, 11.707067527152526, 6.859609879190933, 3.10968981189989], "isController": false}, {"data": ["/root/add_user", 1206, 0, 0.0, 68.047263681592, 15, 502, 109.29999999999995, 150.64999999999986, 225.72000000000025, 23.444334285880913, 13.736914620633346, 6.628061304455589], "isController": false}, {"data": ["/customer/modify_gateway", 598, 0, 0.0, 72.22240802675584, 19, 438, 137.0, 167.04999999999995, 222.01, 11.703689206380272, 6.8233422423916235, 4.548894828261083], "isController": false}, {"data": ["/root/disable_user", 601, 0, 0.0, 68.29284525790345, 15, 281, 110.60000000000014, 150.89999999999998, 243.98000000000002, 11.721797472304571, 6.86824070642846, 2.9647905716082854], "isController": false}, {"data": ["/customer/register_project", 600, 0, 0.0, 79.53166666666667, 21, 487, 136.89999999999998, 186.8499999999998, 277.93000000000006, 11.720810298685317, 48.574383955431614, 3.971798021136528], "isController": false}, {"data": ["/customer/query_project", 599, 0, 0.0, 278.51419031719536, 118, 595, 423.0, 482.0, 545.0, 11.712028781479743, 1617.0455906362429, 3.008069892118333], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["404/NOT FOUND", 597, 100.0, 4.7444965429547805], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 12583, 597, "404/NOT FOUND", 597, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [" /customer/query_last_data", 597, 597, "404/NOT FOUND", 597, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
